import java.util.Scanner;

public class Product {
    private int number;
    private String id;
    private String name;
    private double price;
    private int honorary_code;
    private String state;

    public Product(int number, String id, String name, double price, int honorary_code, String state) {
        this.number = number;
        this.id = id;
        this.name = name;
        this.price = price;
        this.honorary_code = honorary_code;
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    public void startSale() {
        switch (getState()) {
            case "на торгах":
                System.out.println("Товар уже на торгах ");
                break;
            default:
            case "на складе":
                setState("на торгах");
                System.out.println("Товар на торгах");
                break;
            case "продан":
                setState("на торгах");
                System.out.println("Товар на торгах");
                break;
        }
    }

    public void withdraw() {
        switch (getState()){
            case "на торгах":
                setState("на складе");
                break;
            default:
            case "на складе":
                System.out.println("нельзя снять с торгов товар, который в них не участвует");
                break;
            case "продан":
                System.out.println("нельзя снять с торгов, так как товар уже продан");
                break;
        }
    }

    public void giveToTheWinner() {
        switch (getState()){
            case "на торгах":
                setState("продан");
                setHonorary_code(1);
                break;
            default:
            case "на складе":
                System.out.println("нельзя отдать товар сразу со склада");
                break;
            case "продан":
                System.out.println("нельзя выдать покупателю, так как товар уже продан");
                break;
        }
    }

    @Override
    public String toString() {
        return "Products{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", honorary_code=" + honorary_code +
                ", state='" + state + '\'' +
                '}';
    }

    public double raisePrice() {
        Scanner sc = new Scanner(System.in);
        double newPrice = getPrice();
        switch (getState()) {
            case "на торгах":
                System.out.println("Введите новую стоимость товара: ");
                newPrice = sc.nextDouble();
                break;
            default:
            case "на складе":
                System.out.println("Товар на складе, еще не участвует в торгах");
                break;
            case "продан":
                System.out.println("Нельзя повысить стоимость, так как товар уже продан");
                break;
        }
        return newPrice;

    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getNumber() {
        return number;
    }

    public void setHonorary_code(int honorary_code) {
        this.honorary_code = honorary_code;
    }
}
