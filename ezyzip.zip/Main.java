import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Product product1 = new Product(1, "Laptop","Lenovo Yoga 5", 50000, 0, "на складе");
        Product product2 = new Product(2, "Laptop", "Samsung Tree Y5", 75000.5, 0, "на торгах");
        Product product3 = new Product(3, "Laptop", "Samsung NoteBook", 75000.5, 0, "на складе");
        Product product4 = new Product(4, "Mobile", "Iphone 13 pro max", 100550, 0, "продан");

        Product[] products = {product1, product2, product3, product4};
        for (;;){
            for (Product p: products){
                System.out.println(p.toString());
            }
        System.out.println("Введите порядковый номер товара: ");
        Scanner sc = new Scanner(System.in);
        int numberProduct = sc.nextInt();

        for (Product product: products) {
            if (numberProduct == product.getNumber()) {
                System.out.println("1-Поднять цену");
                System.out.println("2-Выставить на торги");
                System.out.println("3-Выдать товар победителю торгов");
                System.out.println("4-Снять товар с торгов");

                System.out.println("Введите номер действия:");
                int antwort = sc.nextInt();
                if(antwort == 1){
                    product.setPrice(product.raisePrice());
                }

                if (antwort == 2){
                    product.startSale();
                }

                if (antwort == 3){
                    product.giveToTheWinner();
                }

                if (antwort==4){
                    product.withdraw();
                }

                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                String json = gson.toJson(product);
                System.out.println(json);
            }

        }
    }
    }
}